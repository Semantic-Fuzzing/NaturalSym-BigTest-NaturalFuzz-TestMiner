import org.apache.spark.rdd.RDD

object template {
  def execute(input1: RDD[String], input2: RDD[String]): RDD[String] = {
    // Парсим первый вход: name,email,age
    val people = input1.map(_.split(","))
      .filter(_.length >= 3)
      .map(arr => (arr(0), arr(1), arr(2).toInt))  // (name, email, age)

    // Фильтруем по возрасту <18
    people.filter { case (_, _, age) => age < 18 }
          .map { case (name, email, age) => s"$name,$email,$age,invalid" }
  }
}