package de.tu.darmstadt.sola;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

  public static boolean debug = false;

  @Test
  public void test001() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test001"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }

  }

  @Test
  public void test002() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test002"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b5 = experimentClass0.isValidUser(user4);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("hi!");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);

  }

  @Test
  public void test003() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test003"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("newpass");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);

  }

  @Test
  public void test004() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test004"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("history", "", (int)(byte)-1);

  }

  @Test
  public void test005() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test005"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("ksessionThatHasBeenRemovedFromKModuleXML");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);

  }

  @Test
  public void test006() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test006"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User(".sh", "testbundle", (int)(byte)1);

  }

  @Test
  public void test007() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test007"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("/server/path?one=1&two=2;three=3&duplicate=A;duplicate=B#fragment", "", (-1));

  }

  @Test
  public void test008() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test008"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b5 = experimentClass0.isValidUser(user4);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);

  }

  @Test
  public void test009() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test009"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user6 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("/server/path?one=1&two=2;three=3&duplicate=A;duplicate=B#fragment");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user6);

  }

  @Test
  public void test010() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test010"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b5 = experimentClass0.isValidUser(user4);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("Strong");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);

  }

  @Test
  public void test011() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test011"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User(".nt", "gonzo", (int)(byte)100);

  }

  @Test
  public void test012() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test012"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b5 = experimentClass0.isValidUser(user4);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("gonzo");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);

  }

  @Test
  public void test013() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test013"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    de.tu.darmstadt.sola.ExperimentClass.User user14 = new de.tu.darmstadt.sola.ExperimentClass.User("gonzo", "ksessionThatHasBeenRemovedFromKModuleXML", (int)'4');
    boolean b15 = experimentClass0.isValidUser(user14);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers(".sh");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b15 == false);

  }

  @Test
  public void test014() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test014"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b5 = experimentClass0.isValidUser(user4);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("fozzie");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == false);

  }

  @Test
  public void test015() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test015"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers(".tmp");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);

  }

  @Test
  public void test016() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test016"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    de.tu.darmstadt.sola.ExperimentClass.User user14 = new de.tu.darmstadt.sola.ExperimentClass.User("gonzo", "ksessionThatHasBeenRemovedFromKModuleXML", (int)'4');
    boolean b15 = experimentClass0.isValidUser(user14);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("wrongSecret");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b15 == false);

  }

  @Test
  public void test017() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test017"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("bundle", "history", (int)(byte)100);

  }

  @Test
  public void test018() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test018"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user13 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("bundle");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user13);

  }

  @Test
  public void test019() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test019"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers(".jar");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);

  }

  @Test
  public void test020() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test020"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "MyClient/1.0", (int)(short)0);

  }

  @Test
  public void test021() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test021"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b5 = experimentClass0.isValidUser(user4);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers(".tmp");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);

  }

  @Test
  public void test022() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test022"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b17 = experimentClass0.isValidUser(user16);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);

  }

  @Test
  public void test023() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test023"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b5 = experimentClass0.isValidUser(user4);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("/context/servlet/path?one=1&two=2;three=3#fragment");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == false);

  }

  @Test
  public void test024() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test024"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user8 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("bundle");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user8);

  }

  @Test
  public void test025() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test025"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User(".test", ".bundle.zip", (int)(byte)1);

  }

  @Test
  public void test026() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test026"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user8 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user9 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user10 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers(".tmp");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user8);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user9);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user10);

  }

  @Test
  public void test027() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test027"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("bundle", "sampleInitParameter", (int)(short)0);

  }

  @Test
  public void test028() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test028"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("fozzie");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);

  }

  @Test
  public void test029() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test029"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b17 = experimentClass0.isValidUser(user16);
    de.tu.darmstadt.sola.ExperimentClass experimentClass18 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b23 = experimentClass18.isValidUser(user22);
    boolean b24 = experimentClass0.isValidUser(user22);
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b29 = experimentClass0.isValidUser(user28);
    de.tu.darmstadt.sola.ExperimentClass experimentClass30 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user34 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b35 = experimentClass30.isValidUser(user34);
    de.tu.darmstadt.sola.ExperimentClass.User user39 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b40 = experimentClass30.isValidUser(user39);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user41 = experimentClass30.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user42 = experimentClass30.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user46 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b47 = experimentClass30.isValidUser(user46);
    de.tu.darmstadt.sola.ExperimentClass experimentClass48 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user52 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b53 = experimentClass48.isValidUser(user52);
    boolean b54 = experimentClass30.isValidUser(user52);
    de.tu.darmstadt.sola.ExperimentClass.User user58 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b59 = experimentClass30.isValidUser(user58);
    boolean b60 = experimentClass0.isValidUser(user58);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("hi!");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user41);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user42);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b60 == true);

  }

  @Test
  public void test030() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test030"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass13 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user17 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b18 = experimentClass13.isValidUser(user17);
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b23 = experimentClass13.isValidUser(user22);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user24 = experimentClass13.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user25 = experimentClass13.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user29 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b30 = experimentClass13.isValidUser(user29);
    de.tu.darmstadt.sola.ExperimentClass experimentClass31 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user35 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b36 = experimentClass31.isValidUser(user35);
    boolean b37 = experimentClass13.isValidUser(user35);
    de.tu.darmstadt.sola.ExperimentClass.User user41 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b42 = experimentClass13.isValidUser(user41);
    boolean b43 = experimentClass0.isValidUser(user41);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("/context/servlet/path?one=1&two=2;three=3#fragment");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user24);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user25);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b43 == true);

  }

  @Test
  public void test031() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test031"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("bundle", "hi!", (int)(short)-1);

  }

  @Test
  public void test032() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test032"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", "", 0);

  }

  @Test
  public void test033() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test033"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("bundle", "ksession2", (int)'4');

  }

  @Test
  public void test034() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test034"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b17 = experimentClass0.isValidUser(user16);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("multipleEntities");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);

  }

  @Test
  public void test035() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test035"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("", "/context/servlet/path?one=1&two=2;three=3#fragment", (int)(byte)0);

  }

  @Test
  public void test036() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test036"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user8 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user9 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("hi!");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user8);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user9);

  }

  @Test
  public void test037() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test037"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "testbundle", 0);

  }

  @Test
  public void test038() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test038"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("/context/servlet/path?name=value");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);

  }

  @Test
  public void test039() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test039"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass experimentClass6 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass6.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user11 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b12 = experimentClass6.isValidUser(user11);
    boolean b13 = experimentClass0.isValidUser(user11);
    de.tu.darmstadt.sola.ExperimentClass.User user17 = new de.tu.darmstadt.sola.ExperimentClass.User("ksessionThatHasBeenRemovedFromKModuleXML", "/test", (int)' ');
    boolean b18 = experimentClass0.isValidUser(user17);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("multipleEntities");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b18 == false);

  }

  @Test
  public void test040() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test040"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b17 = experimentClass0.isValidUser(user16);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user18 = experimentClass0.getInvalidUsers();
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user18);

  }

  @Test
  public void test041() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test041"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass experimentClass6 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user10 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b11 = experimentClass6.isValidUser(user10);
    boolean b12 = experimentClass0.isValidUser(user10);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("sampleInitParameter");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b12 == true);

  }

  @Test
  public void test042() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test042"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b17 = experimentClass0.isValidUser(user16);
    de.tu.darmstadt.sola.ExperimentClass experimentClass18 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b23 = experimentClass18.isValidUser(user22);
    boolean b24 = experimentClass0.isValidUser(user22);
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b29 = experimentClass0.isValidUser(user28);
    de.tu.darmstadt.sola.ExperimentClass experimentClass30 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user34 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b35 = experimentClass30.isValidUser(user34);
    de.tu.darmstadt.sola.ExperimentClass.User user39 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b40 = experimentClass30.isValidUser(user39);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user41 = experimentClass30.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user42 = experimentClass30.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user46 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b47 = experimentClass30.isValidUser(user46);
    de.tu.darmstadt.sola.ExperimentClass experimentClass48 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user52 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b53 = experimentClass48.isValidUser(user52);
    boolean b54 = experimentClass30.isValidUser(user52);
    de.tu.darmstadt.sola.ExperimentClass.User user58 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b59 = experimentClass30.isValidUser(user58);
    boolean b60 = experimentClass0.isValidUser(user58);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("multipleEntities");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user41);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user42);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b60 == true);

  }

  @Test
  public void test043() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test043"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("quadExample", "admin", (int)'a');

  }

  @Test
  public void test044() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test044"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("sampleInitParameter", "gonzo@muppetshow.com", (int)(byte)-1);

  }

  @Test
  public void test045() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test045"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user11 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b12 = experimentClass0.isValidUser(user11);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("/context/servlet/path?one=1&two=2;three=3#fragment");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b12 == true);

  }

  @Test
  public void test046() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test046"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("", "testbundle", (int)'#');

  }

  @Test
  public void test047() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test047"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user8 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("/context/servlet/path?one=1&two=2;three=3#fragment");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user8);

  }

  @Test
  public void test048() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test048"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    de.tu.darmstadt.sola.ExperimentClass experimentClass11 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass11.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b17 = experimentClass11.isValidUser(user16);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user18 = experimentClass11.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("sampleInitParameter", "DECIMAL[(M[,D])]{n}", (int)(byte)100);
    boolean b23 = experimentClass11.isValidUser(user22);
    boolean b24 = experimentClass0.isValidUser(user22);
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User(".jar", "", 100);
    boolean b29 = experimentClass0.isValidUser(user28);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user30 = experimentClass0.getInvalidUsers();
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user18);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user30);

  }

  @Test
  public void test049() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test049"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user8 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user9 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers(".bundle.zip");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user8);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user9);

  }

  @Test
  public void test050() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test050"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User(".bundle.zip", "/test", (int)(short)10);

  }

  @Test
  public void test051() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test051"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b17 = experimentClass0.isValidUser(user16);
    de.tu.darmstadt.sola.ExperimentClass experimentClass18 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b23 = experimentClass18.isValidUser(user22);
    boolean b24 = experimentClass0.isValidUser(user22);
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b29 = experimentClass0.isValidUser(user28);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user30 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass31 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user35 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b36 = experimentClass31.isValidUser(user35);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user37 = experimentClass31.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user41 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b42 = experimentClass31.isValidUser(user41);
    boolean b43 = experimentClass0.isValidUser(user41);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user44 = experimentClass0.getInvalidUsers();
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user30);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user37);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user44);

  }

  @Test
  public void test052() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test052"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b17 = experimentClass0.isValidUser(user16);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == false);

  }

  @Test
  public void test053() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test053"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b17 = experimentClass0.isValidUser(user16);
    de.tu.darmstadt.sola.ExperimentClass experimentClass18 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b23 = experimentClass18.isValidUser(user22);
    boolean b24 = experimentClass0.isValidUser(user22);
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b29 = experimentClass0.isValidUser(user28);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user30 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass31 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user35 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b36 = experimentClass31.isValidUser(user35);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user37 = experimentClass31.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user41 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b42 = experimentClass31.isValidUser(user41);
    boolean b43 = experimentClass0.isValidUser(user41);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user30);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user37);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b43 == false);

  }

  @Test
  public void test054() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test054"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b17 = experimentClass0.isValidUser(user16);
    de.tu.darmstadt.sola.ExperimentClass experimentClass18 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b23 = experimentClass18.isValidUser(user22);
    boolean b24 = experimentClass0.isValidUser(user22);
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b29 = experimentClass0.isValidUser(user28);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user30 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass31 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user35 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b36 = experimentClass31.isValidUser(user35);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user37 = experimentClass31.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user41 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b42 = experimentClass31.isValidUser(user41);
    boolean b43 = experimentClass0.isValidUser(user41);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("sampleInitParameter");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user30);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user37);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b43 == false);

  }

  @Test
  public void test055() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test055"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b5 = experimentClass0.isValidUser(user4);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user6 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user10 = new de.tu.darmstadt.sola.ExperimentClass.User("/context/servlet/path?one=1&two=2;three=3#fragment", "gonzo@muppetshow.com", (int)' ');
    boolean b11 = experimentClass0.isValidUser(user10);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("history");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user6);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b11 == false);

  }

  @Test
  public void test056() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test056"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass experimentClass6 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user10 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b11 = experimentClass6.isValidUser(user10);
    boolean b12 = experimentClass0.isValidUser(user10);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user13 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user14 = experimentClass0.getInvalidUsers();
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user13);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user14);

  }

  @Test
  public void test057() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test057"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b5 = experimentClass0.isValidUser(user4);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user6 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("/context/servlet/path?one=1&two=2;three=3#fragment");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user6);

  }

  @Test
  public void test058() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test058"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user6 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user10 = new de.tu.darmstadt.sola.ExperimentClass.User("DECIMAL[(M[,D])]{n}", "gonzo@muppetshow.com", (int)(byte)-1);
    boolean b11 = experimentClass0.isValidUser(user10);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("ksessionThatHasBeenRemovedFromKModuleXML");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user6);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b11 == true);

  }

  @Test
  public void test059() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test059"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("DECIMAL[(M[,D])]{n}");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);

  }

  @Test
  public void test060() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test060"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass experimentClass6 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass6.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user11 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b12 = experimentClass6.isValidUser(user11);
    boolean b13 = experimentClass0.isValidUser(user11);
    de.tu.darmstadt.sola.ExperimentClass.User user17 = new de.tu.darmstadt.sola.ExperimentClass.User("ksessionThatHasBeenRemovedFromKModuleXML", "/test", (int)' ');
    boolean b18 = experimentClass0.isValidUser(user17);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user19 = experimentClass0.getInvalidUsers();
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user19);

  }

  @Test
  public void test061() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test061"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b17 = experimentClass0.isValidUser(user16);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("hi!");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);

  }

  @Test
  public void test062() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test062"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("id", ".txt", 0);

  }

  @Test
  public void test063() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test063"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b17 = experimentClass0.isValidUser(user16);
    de.tu.darmstadt.sola.ExperimentClass experimentClass18 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b23 = experimentClass18.isValidUser(user22);
    boolean b24 = experimentClass0.isValidUser(user22);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user25 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass26 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user30 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b31 = experimentClass26.isValidUser(user30);
    de.tu.darmstadt.sola.ExperimentClass experimentClass32 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user33 = experimentClass32.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user37 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b38 = experimentClass32.isValidUser(user37);
    boolean b39 = experimentClass26.isValidUser(user37);
    de.tu.darmstadt.sola.ExperimentClass.User user43 = new de.tu.darmstadt.sola.ExperimentClass.User("ksessionThatHasBeenRemovedFromKModuleXML", "/test", (int)' ');
    boolean b44 = experimentClass26.isValidUser(user43);
    boolean b45 = experimentClass0.isValidUser(user43);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user46 = experimentClass0.getInvalidUsers();
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user25);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user33);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user46);

  }

  @Test
  public void test064() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test064"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b17 = experimentClass0.isValidUser(user16);
    de.tu.darmstadt.sola.ExperimentClass experimentClass18 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b23 = experimentClass18.isValidUser(user22);
    boolean b24 = experimentClass0.isValidUser(user22);
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b29 = experimentClass0.isValidUser(user28);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user30 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user34 = new de.tu.darmstadt.sola.ExperimentClass.User("admin", "/servlet/path", 0);
    boolean b35 = experimentClass0.isValidUser(user34);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user30);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b35 == true);

  }

  @Test
  public void test065() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test065"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b17 = experimentClass0.isValidUser(user16);
    de.tu.darmstadt.sola.ExperimentClass experimentClass18 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b23 = experimentClass18.isValidUser(user22);
    boolean b24 = experimentClass0.isValidUser(user22);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user25 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass26 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user30 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b31 = experimentClass26.isValidUser(user30);
    de.tu.darmstadt.sola.ExperimentClass experimentClass32 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user33 = experimentClass32.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user37 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b38 = experimentClass32.isValidUser(user37);
    boolean b39 = experimentClass26.isValidUser(user37);
    de.tu.darmstadt.sola.ExperimentClass.User user43 = new de.tu.darmstadt.sola.ExperimentClass.User("ksessionThatHasBeenRemovedFromKModuleXML", "/test", (int)' ');
    boolean b44 = experimentClass26.isValidUser(user43);
    boolean b45 = experimentClass0.isValidUser(user43);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("ksessionThatHasBeenRemovedFromKModuleXML");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user25);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user33);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b45 == false);

  }

  @Test
  public void test066() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test066"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user6 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user7 = null;
    // The following exception was thrown during execution in test generation
    try {
    boolean b8 = experimentClass0.isValidUser(user7);
      org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
    } catch (java.lang.NullPointerException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user6);

  }

  @Test
  public void test067() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test067"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user6 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user10 = new de.tu.darmstadt.sola.ExperimentClass.User("DECIMAL[(M[,D])]{n}", "gonzo@muppetshow.com", (int)(byte)-1);
    boolean b11 = experimentClass0.isValidUser(user10);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("hi!");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user6);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b11 == true);

  }

  @Test
  public void test068() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test068"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("multipleEntities", ".jar", (int)(byte)1);

  }

  @Test
  public void test069() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test069"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers(".sh");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);

  }

  @Test
  public void test070() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test070"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user11 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b12 = experimentClass0.isValidUser(user11);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("id");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b12 == true);

  }

  @Test
  public void test071() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test071"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "quadExample", 10);

  }

  @Test
  public void test072() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test072"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("shoesize", "foo", (int)(byte)0);

  }

  @Test
  public void test073() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test073"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("MyClient/1.0");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);

  }

  @Test
  public void test074() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test074"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("sampleInitParameter", "MyClient/1.0", (int)(short)0);

  }

  @Test
  public void test075() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test075"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("default://object/store", "ksessionThatHasBeenRemovedFromKModuleXML", 0);

  }

  @Test
  public void test076() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test076"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user6 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user6);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);

  }

  @Test
  public void test077() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test077"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("zip", "ksession2", (int)(byte)0);

  }

  @Test
  public void test078() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test078"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass experimentClass6 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass6.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user11 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b12 = experimentClass6.isValidUser(user11);
    boolean b13 = experimentClass0.isValidUser(user11);
    de.tu.darmstadt.sola.ExperimentClass.User user17 = new de.tu.darmstadt.sola.ExperimentClass.User("ksessionThatHasBeenRemovedFromKModuleXML", "/test", (int)' ');
    boolean b18 = experimentClass0.isValidUser(user17);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers(".sh");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b18 == false);

  }

  @Test
  public void test079() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test079"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass13 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user17 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b18 = experimentClass13.isValidUser(user17);
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b23 = experimentClass13.isValidUser(user22);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user24 = experimentClass13.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user25 = experimentClass13.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user29 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b30 = experimentClass13.isValidUser(user29);
    de.tu.darmstadt.sola.ExperimentClass experimentClass31 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user35 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b36 = experimentClass31.isValidUser(user35);
    boolean b37 = experimentClass13.isValidUser(user35);
    de.tu.darmstadt.sola.ExperimentClass.User user41 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b42 = experimentClass13.isValidUser(user41);
    boolean b43 = experimentClass0.isValidUser(user41);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user44 = experimentClass0.getInvalidUsers();
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user24);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user25);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user44);

  }

  @Test
  public void test080() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test080"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user11 = new de.tu.darmstadt.sola.ExperimentClass.User("sampleInitParameter", "DECIMAL[(M[,D])]{n}", (int)(byte)100);
    boolean b12 = experimentClass0.isValidUser(user11);
    de.tu.darmstadt.sola.ExperimentClass experimentClass13 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user14 = experimentClass13.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user18 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b19 = experimentClass13.isValidUser(user18);
    boolean b20 = experimentClass0.isValidUser(user18);
    de.tu.darmstadt.sola.ExperimentClass experimentClass21 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user25 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b26 = experimentClass21.isValidUser(user25);
    boolean b27 = experimentClass0.isValidUser(user25);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user14);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b27 == false);

  }

  @Test
  public void test081() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test081"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("integer", "zip", (int)'#');

  }

  @Test
  public void test082() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test082"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user6 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user10 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b11 = experimentClass0.isValidUser(user10);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("zip");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user6);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b11 == false);

  }

  @Test
  public void test083() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test083"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("admin");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }

  }

  @Test
  public void test084() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test084"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("zip", ".tmp", (int)(byte)1);

  }

  @Test
  public void test085() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test085"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("", "history", (int)' ');

  }

  @Test
  public void test086() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test086"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("INTEGER[(L)] [UNSIGNED]", "", 0);

  }

  @Test
  public void test087() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test087"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass experimentClass6 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass6.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user11 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b12 = experimentClass6.isValidUser(user11);
    boolean b13 = experimentClass0.isValidUser(user11);
    de.tu.darmstadt.sola.ExperimentClass.User user14 = null;
    // The following exception was thrown during execution in test generation
    try {
    boolean b15 = experimentClass0.isValidUser(user14);
      org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
    } catch (java.lang.NullPointerException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b13 == true);

  }

  @Test
  public void test088() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test088"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("/test", "Gonzo", (int)(byte)100);

  }

  @Test
  public void test089() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test089"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("history", "gonzo@muppetshow.com", 0);

  }

  @Test
  public void test090() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test090"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("/test?type=REQUEST", "/servlet/path", 100);

  }

  @Test
  public void test091() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test091"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("Thefrog", "hi!", (int)' ');

  }

  @Test
  public void test092() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test092"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b17 = experimentClass0.isValidUser(user16);
    de.tu.darmstadt.sola.ExperimentClass experimentClass18 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b23 = experimentClass18.isValidUser(user22);
    boolean b24 = experimentClass0.isValidUser(user22);
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b29 = experimentClass0.isValidUser(user28);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user30 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user34 = new de.tu.darmstadt.sola.ExperimentClass.User(".nt", "multipleEntities", (int)' ');
    boolean b35 = experimentClass0.isValidUser(user34);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user36 = experimentClass0.getInvalidUsers();
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user30);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user36);

  }

  @Test
  public void test093() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test093"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user11 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b12 = experimentClass0.isValidUser(user11);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user13 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers(".txt");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user13);

  }

  @Test
  public void test094() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test094"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass experimentClass6 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user10 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b11 = experimentClass6.isValidUser(user10);
    de.tu.darmstadt.sola.ExperimentClass.User user15 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b16 = experimentClass6.isValidUser(user15);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user17 = experimentClass6.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user18 = experimentClass6.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b23 = experimentClass6.isValidUser(user22);
    de.tu.darmstadt.sola.ExperimentClass experimentClass24 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b29 = experimentClass24.isValidUser(user28);
    boolean b30 = experimentClass6.isValidUser(user28);
    de.tu.darmstadt.sola.ExperimentClass.User user34 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b35 = experimentClass6.isValidUser(user34);
    boolean b36 = experimentClass0.isValidUser(user34);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user37 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("bundle");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user17);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user18);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user37);

  }

  @Test
  public void test095() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test095"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user8 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user12 = new de.tu.darmstadt.sola.ExperimentClass.User("", "/context/servlet/path?one=1&two=2;three=3#fragment", (int)(short)100);
    boolean b13 = experimentClass0.isValidUser(user12);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("role");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user8);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b13 == false);

  }

  @Test
  public void test096() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test096"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("ksession2", "id", (int)'#');

  }

  @Test
  public void test097() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test097"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User(".ttl", "fozzie@muppetshow.com", (int)(byte)10);

  }

  @Test
  public void test098() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test098"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass experimentClass6 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass6.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user11 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b12 = experimentClass6.isValidUser(user11);
    boolean b13 = experimentClass0.isValidUser(user11);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user14 = experimentClass0.getInvalidUsers();
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user14);

  }

  @Test
  public void test099() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test099"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("", "admin", (int)(byte)100);

  }

  @Test
  public void test100() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test100"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass experimentClass6 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass6.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user11 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b12 = experimentClass6.isValidUser(user11);
    boolean b13 = experimentClass0.isValidUser(user11);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("Strong");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b13 == true);

  }

  @Test
  public void test101() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test101"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass experimentClass6 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user10 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b11 = experimentClass6.isValidUser(user10);
    de.tu.darmstadt.sola.ExperimentClass.User user15 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b16 = experimentClass6.isValidUser(user15);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user17 = experimentClass6.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user18 = experimentClass6.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b23 = experimentClass6.isValidUser(user22);
    de.tu.darmstadt.sola.ExperimentClass experimentClass24 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b29 = experimentClass24.isValidUser(user28);
    boolean b30 = experimentClass6.isValidUser(user28);
    de.tu.darmstadt.sola.ExperimentClass.User user34 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b35 = experimentClass6.isValidUser(user34);
    boolean b36 = experimentClass0.isValidUser(user34);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user37 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass38 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user42 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b43 = experimentClass38.isValidUser(user42);
    de.tu.darmstadt.sola.ExperimentClass.User user47 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b48 = experimentClass38.isValidUser(user47);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user49 = experimentClass38.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user50 = experimentClass38.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user54 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b55 = experimentClass38.isValidUser(user54);
    de.tu.darmstadt.sola.ExperimentClass experimentClass56 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user60 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b61 = experimentClass56.isValidUser(user60);
    boolean b62 = experimentClass38.isValidUser(user60);
    de.tu.darmstadt.sola.ExperimentClass.User user66 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b67 = experimentClass38.isValidUser(user66);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user68 = experimentClass38.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass69 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user73 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b74 = experimentClass69.isValidUser(user73);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user75 = experimentClass69.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user79 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b80 = experimentClass69.isValidUser(user79);
    boolean b81 = experimentClass38.isValidUser(user79);
    boolean b82 = experimentClass0.isValidUser(user79);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user17);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user18);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user37);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user49);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user50);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b67 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user68);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b74 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user75);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b82 == false);

  }

  @Test
  public void test102() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test102"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user13 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers(".jar");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user13);

  }

  @Test
  public void test103() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test103"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    de.tu.darmstadt.sola.ExperimentClass experimentClass11 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass11.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b17 = experimentClass11.isValidUser(user16);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user18 = experimentClass11.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("sampleInitParameter", "DECIMAL[(M[,D])]{n}", (int)(byte)100);
    boolean b23 = experimentClass11.isValidUser(user22);
    boolean b24 = experimentClass0.isValidUser(user22);
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User(".jar", "", 100);
    boolean b29 = experimentClass0.isValidUser(user28);
    de.tu.darmstadt.sola.ExperimentClass.User user33 = new de.tu.darmstadt.sola.ExperimentClass.User("DECIMAL[(M[,D])]{n}", "gonzo@muppetshow.com", (int)(byte)-1);
    boolean b34 = experimentClass0.isValidUser(user33);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user35 = experimentClass0.getInvalidUsers();
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user18);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user35);

  }

  @Test
  public void test104() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test104"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User(".sh", ".jar", (int)(short)10);

  }

  @Test
  public void test105() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test105"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    de.tu.darmstadt.sola.ExperimentClass experimentClass11 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass11.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b17 = experimentClass11.isValidUser(user16);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user18 = experimentClass11.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("sampleInitParameter", "DECIMAL[(M[,D])]{n}", (int)(byte)100);
    boolean b23 = experimentClass11.isValidUser(user22);
    boolean b24 = experimentClass0.isValidUser(user22);
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User(".jar", "", 100);
    boolean b29 = experimentClass0.isValidUser(user28);
    de.tu.darmstadt.sola.ExperimentClass experimentClass30 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user34 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b35 = experimentClass30.isValidUser(user34);
    de.tu.darmstadt.sola.ExperimentClass.User user39 = new de.tu.darmstadt.sola.ExperimentClass.User("/context/servlet/path?one=1&two=2;three=3#fragment", ".nt", 100);
    boolean b40 = experimentClass30.isValidUser(user39);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user41 = experimentClass30.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass42 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user46 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b47 = experimentClass42.isValidUser(user46);
    de.tu.darmstadt.sola.ExperimentClass.User user51 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b52 = experimentClass42.isValidUser(user51);
    de.tu.darmstadt.sola.ExperimentClass experimentClass53 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user54 = experimentClass53.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user58 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b59 = experimentClass53.isValidUser(user58);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user60 = experimentClass53.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user64 = new de.tu.darmstadt.sola.ExperimentClass.User("sampleInitParameter", "DECIMAL[(M[,D])]{n}", (int)(byte)100);
    boolean b65 = experimentClass53.isValidUser(user64);
    boolean b66 = experimentClass42.isValidUser(user64);
    de.tu.darmstadt.sola.ExperimentClass.User user70 = new de.tu.darmstadt.sola.ExperimentClass.User(".jar", "", 100);
    boolean b71 = experimentClass42.isValidUser(user70);
    de.tu.darmstadt.sola.ExperimentClass.User user75 = new de.tu.darmstadt.sola.ExperimentClass.User("DECIMAL[(M[,D])]{n}", "gonzo@muppetshow.com", (int)(byte)-1);
    boolean b76 = experimentClass42.isValidUser(user75);
    boolean b77 = experimentClass30.isValidUser(user75);
    boolean b78 = experimentClass0.isValidUser(user75);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user18);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user41);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user54);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user60);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b76 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b77 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b78 == true);

  }

  @Test
  public void test106() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test106"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User(".test", "/context/servlet/path?name=value", 1);

  }

  @Test
  public void test107() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test107"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass experimentClass6 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass6.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user11 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b12 = experimentClass6.isValidUser(user11);
    boolean b13 = experimentClass0.isValidUser(user11);
    de.tu.darmstadt.sola.ExperimentClass.User user17 = new de.tu.darmstadt.sola.ExperimentClass.User("ksessionThatHasBeenRemovedFromKModuleXML", "/test", (int)' ');
    boolean b18 = experimentClass0.isValidUser(user17);
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("MyClient/1.0", "/context/servlet/path?name=value", (int)' ');
    boolean b23 = experimentClass0.isValidUser(user22);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user24 = experimentClass0.getInvalidUsers();
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user24);

  }

  @Test
  public void test108() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test108"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user11 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", "/test?type=request-mapping", 10);
    boolean b12 = experimentClass0.isValidUser(user11);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("/servlet/path");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b12 == true);

  }

  @Test
  public void test109() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test109"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user11 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b12 = experimentClass0.isValidUser(user11);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user13 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass14 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user18 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b19 = experimentClass14.isValidUser(user18);
    de.tu.darmstadt.sola.ExperimentClass experimentClass20 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user24 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b25 = experimentClass20.isValidUser(user24);
    de.tu.darmstadt.sola.ExperimentClass.User user29 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b30 = experimentClass20.isValidUser(user29);
    de.tu.darmstadt.sola.ExperimentClass experimentClass31 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user32 = experimentClass31.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user36 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b37 = experimentClass31.isValidUser(user36);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user38 = experimentClass31.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user42 = new de.tu.darmstadt.sola.ExperimentClass.User("sampleInitParameter", "DECIMAL[(M[,D])]{n}", (int)(byte)100);
    boolean b43 = experimentClass31.isValidUser(user42);
    boolean b44 = experimentClass20.isValidUser(user42);
    de.tu.darmstadt.sola.ExperimentClass.User user48 = new de.tu.darmstadt.sola.ExperimentClass.User(".jar", "", 100);
    boolean b49 = experimentClass20.isValidUser(user48);
    boolean b50 = experimentClass14.isValidUser(user48);
    boolean b51 = experimentClass0.isValidUser(user48);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user13);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user32);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user38);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b51 == false);

  }

  @Test
  public void test110() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test110"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User(".omex", "Gonzo", (-1));

  }

  @Test
  public void test111() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test111"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user8 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user9 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user10 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers(".test");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user8);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user9);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user10);

  }

  @Test
  public void test112() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test112"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("multipleEntities", "/servlet/path", (int)(byte)-1);

  }

  @Test
  public void test113() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test113"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b17 = experimentClass0.isValidUser(user16);
    de.tu.darmstadt.sola.ExperimentClass experimentClass18 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b23 = experimentClass18.isValidUser(user22);
    boolean b24 = experimentClass0.isValidUser(user22);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers(".omex");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b24 == false);

  }

  @Test
  public void test114() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test114"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    de.tu.darmstadt.sola.ExperimentClass.User user14 = new de.tu.darmstadt.sola.ExperimentClass.User("gonzo", "ksessionThatHasBeenRemovedFromKModuleXML", (int)'4');
    boolean b15 = experimentClass0.isValidUser(user14);
    de.tu.darmstadt.sola.ExperimentClass.User user19 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b20 = experimentClass0.isValidUser(user19);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user21 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user22 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("testbundle");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user21);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user22);

  }

  @Test
  public void test115() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test115"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user8 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass9 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user13 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b14 = experimentClass9.isValidUser(user13);
    de.tu.darmstadt.sola.ExperimentClass experimentClass15 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user19 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b20 = experimentClass15.isValidUser(user19);
    boolean b21 = experimentClass9.isValidUser(user19);
    boolean b22 = experimentClass0.isValidUser(user19);
    de.tu.darmstadt.sola.ExperimentClass experimentClass23 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass experimentClass24 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b29 = experimentClass24.isValidUser(user28);
    de.tu.darmstadt.sola.ExperimentClass experimentClass30 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user31 = experimentClass30.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user35 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b36 = experimentClass30.isValidUser(user35);
    boolean b37 = experimentClass24.isValidUser(user35);
    de.tu.darmstadt.sola.ExperimentClass.User user41 = new de.tu.darmstadt.sola.ExperimentClass.User("ksessionThatHasBeenRemovedFromKModuleXML", "/test", (int)' ');
    boolean b42 = experimentClass24.isValidUser(user41);
    boolean b43 = experimentClass23.isValidUser(user41);
    boolean b44 = experimentClass0.isValidUser(user41);
    de.tu.darmstadt.sola.ExperimentClass experimentClass45 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user46 = experimentClass45.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user50 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b51 = experimentClass45.isValidUser(user50);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user52 = experimentClass45.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user53 = experimentClass45.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass54 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user58 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b59 = experimentClass54.isValidUser(user58);
    de.tu.darmstadt.sola.ExperimentClass experimentClass60 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user64 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b65 = experimentClass60.isValidUser(user64);
    boolean b66 = experimentClass54.isValidUser(user64);
    boolean b67 = experimentClass45.isValidUser(user64);
    de.tu.darmstadt.sola.ExperimentClass experimentClass68 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass experimentClass69 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user73 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b74 = experimentClass69.isValidUser(user73);
    de.tu.darmstadt.sola.ExperimentClass experimentClass75 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user76 = experimentClass75.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user80 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b81 = experimentClass75.isValidUser(user80);
    boolean b82 = experimentClass69.isValidUser(user80);
    de.tu.darmstadt.sola.ExperimentClass.User user86 = new de.tu.darmstadt.sola.ExperimentClass.User("ksessionThatHasBeenRemovedFromKModuleXML", "/test", (int)' ');
    boolean b87 = experimentClass69.isValidUser(user86);
    boolean b88 = experimentClass68.isValidUser(user86);
    boolean b89 = experimentClass45.isValidUser(user86);
    boolean b90 = experimentClass0.isValidUser(user86);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers(".omex");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user8);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user31);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user46);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user52);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user53);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b67 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b74 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user76);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b81 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b82 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b87 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b88 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b90 == false);

  }

  @Test
  public void test116() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test116"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b5 = experimentClass0.isValidUser(user4);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user6 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user6);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);

  }

  @Test
  public void test117() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test117"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass13 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user17 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b18 = experimentClass13.isValidUser(user17);
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b23 = experimentClass13.isValidUser(user22);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user24 = experimentClass13.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user25 = experimentClass13.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user29 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b30 = experimentClass13.isValidUser(user29);
    de.tu.darmstadt.sola.ExperimentClass experimentClass31 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user35 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b36 = experimentClass31.isValidUser(user35);
    boolean b37 = experimentClass13.isValidUser(user35);
    de.tu.darmstadt.sola.ExperimentClass.User user41 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b42 = experimentClass13.isValidUser(user41);
    boolean b43 = experimentClass0.isValidUser(user41);
    de.tu.darmstadt.sola.ExperimentClass.User user47 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "", (int)'#');
    boolean b48 = experimentClass0.isValidUser(user47);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("ksession2");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user24);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user25);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b48 == false);

  }

  @Test
  public void test118() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test118"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass experimentClass6 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user10 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b11 = experimentClass6.isValidUser(user10);
    de.tu.darmstadt.sola.ExperimentClass.User user15 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b16 = experimentClass6.isValidUser(user15);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user17 = experimentClass6.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user18 = experimentClass6.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b23 = experimentClass6.isValidUser(user22);
    de.tu.darmstadt.sola.ExperimentClass experimentClass24 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b29 = experimentClass24.isValidUser(user28);
    boolean b30 = experimentClass6.isValidUser(user28);
    de.tu.darmstadt.sola.ExperimentClass.User user34 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b35 = experimentClass6.isValidUser(user34);
    boolean b36 = experimentClass0.isValidUser(user34);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers(".bundle.zip");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user17);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user18);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == true);

  }

  @Test
  public void test119() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test119"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b17 = experimentClass0.isValidUser(user16);
    de.tu.darmstadt.sola.ExperimentClass experimentClass18 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b23 = experimentClass18.isValidUser(user22);
    boolean b24 = experimentClass0.isValidUser(user22);
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b29 = experimentClass0.isValidUser(user28);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user30 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("foo");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user30);

  }

  @Test
  public void test120() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test120"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("", ".sh", (int)'4');

  }

  @Test
  public void test121() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test121"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    de.tu.darmstadt.sola.ExperimentClass experimentClass11 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass11.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b17 = experimentClass11.isValidUser(user16);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user18 = experimentClass11.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("sampleInitParameter", "DECIMAL[(M[,D])]{n}", (int)(byte)100);
    boolean b23 = experimentClass11.isValidUser(user22);
    boolean b24 = experimentClass0.isValidUser(user22);
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User(".jar", "", 100);
    boolean b29 = experimentClass0.isValidUser(user28);
    de.tu.darmstadt.sola.ExperimentClass.User user33 = new de.tu.darmstadt.sola.ExperimentClass.User("DECIMAL[(M[,D])]{n}", "gonzo@muppetshow.com", (int)(byte)-1);
    boolean b34 = experimentClass0.isValidUser(user33);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("fozzie");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user18);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b34 == true);

  }

  @Test
  public void test122() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test122"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass13 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user17 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b18 = experimentClass13.isValidUser(user17);
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b23 = experimentClass13.isValidUser(user22);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user24 = experimentClass13.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user25 = experimentClass13.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user29 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b30 = experimentClass13.isValidUser(user29);
    de.tu.darmstadt.sola.ExperimentClass experimentClass31 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user35 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b36 = experimentClass31.isValidUser(user35);
    boolean b37 = experimentClass13.isValidUser(user35);
    de.tu.darmstadt.sola.ExperimentClass.User user41 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b42 = experimentClass13.isValidUser(user41);
    boolean b43 = experimentClass0.isValidUser(user41);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("password");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user24);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user25);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b43 == true);

  }

  @Test
  public void test123() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test123"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass experimentClass6 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass6.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user11 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b12 = experimentClass6.isValidUser(user11);
    boolean b13 = experimentClass0.isValidUser(user11);
    de.tu.darmstadt.sola.ExperimentClass.User user17 = new de.tu.darmstadt.sola.ExperimentClass.User("ksessionThatHasBeenRemovedFromKModuleXML", "/test", (int)' ');
    boolean b18 = experimentClass0.isValidUser(user17);
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("MyClient/1.0", "/context/servlet/path?name=value", (int)' ');
    boolean b23 = experimentClass0.isValidUser(user22);
    de.tu.darmstadt.sola.ExperimentClass.User user27 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "", (int)'#');
    boolean b28 = experimentClass0.isValidUser(user27);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b28 == false);

  }

  @Test
  public void test124() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test124"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass experimentClass1 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b6 = experimentClass1.isValidUser(user5);
    de.tu.darmstadt.sola.ExperimentClass experimentClass7 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user8 = experimentClass7.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user12 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b13 = experimentClass7.isValidUser(user12);
    boolean b14 = experimentClass1.isValidUser(user12);
    de.tu.darmstadt.sola.ExperimentClass.User user18 = new de.tu.darmstadt.sola.ExperimentClass.User("ksessionThatHasBeenRemovedFromKModuleXML", "/test", (int)' ');
    boolean b19 = experimentClass1.isValidUser(user18);
    boolean b20 = experimentClass0.isValidUser(user18);
    de.tu.darmstadt.sola.ExperimentClass experimentClass21 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user25 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b26 = experimentClass21.isValidUser(user25);
    de.tu.darmstadt.sola.ExperimentClass.User user30 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b31 = experimentClass21.isValidUser(user30);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user32 = experimentClass21.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user33 = experimentClass21.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user37 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b38 = experimentClass21.isValidUser(user37);
    de.tu.darmstadt.sola.ExperimentClass experimentClass39 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user43 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b44 = experimentClass39.isValidUser(user43);
    boolean b45 = experimentClass21.isValidUser(user43);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user46 = experimentClass21.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass47 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user51 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b52 = experimentClass47.isValidUser(user51);
    de.tu.darmstadt.sola.ExperimentClass.User user56 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b57 = experimentClass47.isValidUser(user56);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user58 = experimentClass47.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user59 = experimentClass47.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass60 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user64 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b65 = experimentClass60.isValidUser(user64);
    de.tu.darmstadt.sola.ExperimentClass.User user69 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b70 = experimentClass60.isValidUser(user69);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user71 = experimentClass60.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user72 = experimentClass60.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user76 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b77 = experimentClass60.isValidUser(user76);
    de.tu.darmstadt.sola.ExperimentClass experimentClass78 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user82 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b83 = experimentClass78.isValidUser(user82);
    boolean b84 = experimentClass60.isValidUser(user82);
    de.tu.darmstadt.sola.ExperimentClass.User user88 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b89 = experimentClass60.isValidUser(user88);
    boolean b90 = experimentClass47.isValidUser(user88);
    de.tu.darmstadt.sola.ExperimentClass.User user94 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "", (int)'#');
    boolean b95 = experimentClass47.isValidUser(user94);
    boolean b96 = experimentClass21.isValidUser(user94);
    boolean b97 = experimentClass0.isValidUser(user94);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user8);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user32);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user33);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user46);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user58);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user59);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user71);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user72);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b77 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b83 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b89 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b90 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b95 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b96 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b97 == false);

  }

  @Test
  public void test125() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test125"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User(".txt", "gonzo@muppetshow.com", (int)(byte)100);

  }

  @Test
  public void test126() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test126"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b17 = experimentClass0.isValidUser(user16);
    de.tu.darmstadt.sola.ExperimentClass experimentClass18 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b23 = experimentClass18.isValidUser(user22);
    boolean b24 = experimentClass0.isValidUser(user22);
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b29 = experimentClass0.isValidUser(user28);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user30 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user34 = new de.tu.darmstadt.sola.ExperimentClass.User(".nt", "multipleEntities", (int)' ');
    boolean b35 = experimentClass0.isValidUser(user34);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("zip");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user30);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b35 == false);

  }

  @Test
  public void test127() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test127"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)0);

  }

  @Test
  public void test128() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test128"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("/context/servlet/path?one=1&two=2;three=3#fragment", ".nt", 100);
    boolean b10 = experimentClass0.isValidUser(user9);
    de.tu.darmstadt.sola.ExperimentClass.User user14 = new de.tu.darmstadt.sola.ExperimentClass.User("", "/context/servlet/path?one=1&two=2;three=3#fragment", (int)(short)100);
    boolean b15 = experimentClass0.isValidUser(user14);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b15 == false);

  }

  @Test
  public void test129() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test129"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user11 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", "/test?type=request-mapping", 10);
    boolean b12 = experimentClass0.isValidUser(user11);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers(".tmp");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b12 == true);

  }

  @Test
  public void test130() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test130"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b5 = experimentClass0.isValidUser(user4);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user6 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user10 = new de.tu.darmstadt.sola.ExperimentClass.User("/context/servlet/path?one=1&two=2;three=3#fragment", "gonzo@muppetshow.com", (int)' ');
    boolean b11 = experimentClass0.isValidUser(user10);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("shoesize");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user6);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b11 == false);

  }

  @Test
  public void test131() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test131"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User(".xml", "", (int)(byte)100);

  }

  @Test
  public void test132() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test132"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "graph", 1);

  }

  @Test
  public void test133() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test133"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user8 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass9 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user13 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b14 = experimentClass9.isValidUser(user13);
    de.tu.darmstadt.sola.ExperimentClass experimentClass15 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user19 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b20 = experimentClass15.isValidUser(user19);
    boolean b21 = experimentClass9.isValidUser(user19);
    boolean b22 = experimentClass0.isValidUser(user19);
    de.tu.darmstadt.sola.ExperimentClass experimentClass23 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass experimentClass24 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b29 = experimentClass24.isValidUser(user28);
    de.tu.darmstadt.sola.ExperimentClass experimentClass30 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user31 = experimentClass30.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user35 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b36 = experimentClass30.isValidUser(user35);
    boolean b37 = experimentClass24.isValidUser(user35);
    de.tu.darmstadt.sola.ExperimentClass.User user41 = new de.tu.darmstadt.sola.ExperimentClass.User("ksessionThatHasBeenRemovedFromKModuleXML", "/test", (int)' ');
    boolean b42 = experimentClass24.isValidUser(user41);
    boolean b43 = experimentClass23.isValidUser(user41);
    boolean b44 = experimentClass0.isValidUser(user41);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user45 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("id");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user8);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user31);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user45);

  }

  @Test
  public void test134() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test134"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user8 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user9 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user10 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass11 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user15 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b16 = experimentClass11.isValidUser(user15);
    de.tu.darmstadt.sola.ExperimentClass.User user20 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b21 = experimentClass11.isValidUser(user20);
    de.tu.darmstadt.sola.ExperimentClass experimentClass22 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user23 = experimentClass22.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user27 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b28 = experimentClass22.isValidUser(user27);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user29 = experimentClass22.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user33 = new de.tu.darmstadt.sola.ExperimentClass.User("sampleInitParameter", "DECIMAL[(M[,D])]{n}", (int)(byte)100);
    boolean b34 = experimentClass22.isValidUser(user33);
    boolean b35 = experimentClass11.isValidUser(user33);
    boolean b36 = experimentClass0.isValidUser(user33);
    de.tu.darmstadt.sola.ExperimentClass.User user37 = null;
    // The following exception was thrown during execution in test generation
    try {
    boolean b38 = experimentClass0.isValidUser(user37);
      org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
    } catch (java.lang.NullPointerException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user8);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user9);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user10);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user23);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user29);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == false);

  }

  @Test
  public void test135() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test135"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b17 = experimentClass0.isValidUser(user16);
    de.tu.darmstadt.sola.ExperimentClass experimentClass18 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b23 = experimentClass18.isValidUser(user22);
    boolean b24 = experimentClass0.isValidUser(user22);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user25 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass26 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user30 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b31 = experimentClass26.isValidUser(user30);
    de.tu.darmstadt.sola.ExperimentClass.User user35 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b36 = experimentClass26.isValidUser(user35);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user37 = experimentClass26.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user38 = experimentClass26.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass39 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user43 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b44 = experimentClass39.isValidUser(user43);
    de.tu.darmstadt.sola.ExperimentClass.User user48 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b49 = experimentClass39.isValidUser(user48);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user50 = experimentClass39.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user51 = experimentClass39.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user55 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b56 = experimentClass39.isValidUser(user55);
    de.tu.darmstadt.sola.ExperimentClass experimentClass57 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user61 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b62 = experimentClass57.isValidUser(user61);
    boolean b63 = experimentClass39.isValidUser(user61);
    de.tu.darmstadt.sola.ExperimentClass.User user67 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b68 = experimentClass39.isValidUser(user67);
    boolean b69 = experimentClass26.isValidUser(user67);
    de.tu.darmstadt.sola.ExperimentClass.User user73 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "", (int)'#');
    boolean b74 = experimentClass26.isValidUser(user73);
    boolean b75 = experimentClass0.isValidUser(user73);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user76 = experimentClass0.getInvalidUsers();
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user25);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user37);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user38);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user50);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user51);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b69 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user76);

  }

  @Test
  public void test136() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test136"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    de.tu.darmstadt.sola.ExperimentClass.User user14 = new de.tu.darmstadt.sola.ExperimentClass.User("gonzo", "ksessionThatHasBeenRemovedFromKModuleXML", (int)'4');
    boolean b15 = experimentClass0.isValidUser(user14);
    de.tu.darmstadt.sola.ExperimentClass.User user19 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b20 = experimentClass0.isValidUser(user19);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user21 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user22 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("newpass");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user21);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user22);

  }

  @Test
  public void test137() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test137"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("INTEGER[(L)] [UNSIGNED]", "staging", (int)' ');

  }

  @Test
  public void test138() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test138"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("jsf.key", "/context/servlet/path?one=1&two=2;three=3#fragment", (int)(short)-1);

  }

  @Test
  public void test139() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test139"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("quadExample");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);

  }

  @Test
  public void test140() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test140"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("history", "multipleEntities", 0);

  }

  @Test
  public void test141() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test141"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("", ".txt", (int)(byte)-1);

  }

  @Test
  public void test142() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test142"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user6 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user10 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b11 = experimentClass0.isValidUser(user10);
    de.tu.darmstadt.sola.ExperimentClass.User user15 = new de.tu.darmstadt.sola.ExperimentClass.User("/context/servlet/path?one=1&two=2;three=3#fragment", "gonzo@muppetshow.com", (int)' ');
    boolean b16 = experimentClass0.isValidUser(user15);
    de.tu.darmstadt.sola.ExperimentClass experimentClass17 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user18 = experimentClass17.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b23 = experimentClass17.isValidUser(user22);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user24 = experimentClass17.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user25 = experimentClass17.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user26 = experimentClass17.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user27 = experimentClass17.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass28 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user32 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b33 = experimentClass28.isValidUser(user32);
    de.tu.darmstadt.sola.ExperimentClass.User user37 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b38 = experimentClass28.isValidUser(user37);
    de.tu.darmstadt.sola.ExperimentClass experimentClass39 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user40 = experimentClass39.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user44 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b45 = experimentClass39.isValidUser(user44);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user46 = experimentClass39.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user50 = new de.tu.darmstadt.sola.ExperimentClass.User("sampleInitParameter", "DECIMAL[(M[,D])]{n}", (int)(byte)100);
    boolean b51 = experimentClass39.isValidUser(user50);
    boolean b52 = experimentClass28.isValidUser(user50);
    boolean b53 = experimentClass17.isValidUser(user50);
    boolean b54 = experimentClass0.isValidUser(user50);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user6);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user18);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user24);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user25);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user26);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user27);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user40);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user46);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b54 == false);

  }

  @Test
  public void test143() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test143"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User(".ttl", "TEXT [CHARACTER SET]", 0);

  }

  @Test
  public void test144() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test144"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user8 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass9 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user13 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b14 = experimentClass9.isValidUser(user13);
    de.tu.darmstadt.sola.ExperimentClass experimentClass15 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user19 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b20 = experimentClass15.isValidUser(user19);
    boolean b21 = experimentClass9.isValidUser(user19);
    boolean b22 = experimentClass0.isValidUser(user19);
    de.tu.darmstadt.sola.ExperimentClass experimentClass23 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass experimentClass24 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b29 = experimentClass24.isValidUser(user28);
    de.tu.darmstadt.sola.ExperimentClass experimentClass30 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user31 = experimentClass30.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user35 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b36 = experimentClass30.isValidUser(user35);
    boolean b37 = experimentClass24.isValidUser(user35);
    de.tu.darmstadt.sola.ExperimentClass.User user41 = new de.tu.darmstadt.sola.ExperimentClass.User("ksessionThatHasBeenRemovedFromKModuleXML", "/test", (int)' ');
    boolean b42 = experimentClass24.isValidUser(user41);
    boolean b43 = experimentClass23.isValidUser(user41);
    boolean b44 = experimentClass0.isValidUser(user41);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user45 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass46 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user50 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b51 = experimentClass46.isValidUser(user50);
    de.tu.darmstadt.sola.ExperimentClass experimentClass52 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user53 = experimentClass52.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user57 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b58 = experimentClass52.isValidUser(user57);
    boolean b59 = experimentClass46.isValidUser(user57);
    boolean b60 = experimentClass0.isValidUser(user57);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user8);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user31);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user45);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user53);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b60 == true);

  }

  @Test
  public void test145() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test145"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user6 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user10 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b11 = experimentClass0.isValidUser(user10);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user6);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);

  }

  @Test
  public void test146() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test146"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("Gonzo", "[UNSIGNED] INTEGER", (int)'#');

  }

  @Test
  public void test147() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test147"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    de.tu.darmstadt.sola.ExperimentClass.User user14 = new de.tu.darmstadt.sola.ExperimentClass.User("gonzo", "ksessionThatHasBeenRemovedFromKModuleXML", (int)'4');
    boolean b15 = experimentClass0.isValidUser(user14);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user16 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user20 = new de.tu.darmstadt.sola.ExperimentClass.User("Gonzo", "staging", (int)(short)1);
    boolean b21 = experimentClass0.isValidUser(user20);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user16);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b21 == true);

  }

  @Test
  public void test148() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test148"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User(".omex", "fozzie", 100);

  }

  @Test
  public void test149() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test149"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    de.tu.darmstadt.sola.ExperimentClass.User user14 = new de.tu.darmstadt.sola.ExperimentClass.User("gonzo", "ksessionThatHasBeenRemovedFromKModuleXML", (int)'4');
    boolean b15 = experimentClass0.isValidUser(user14);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user16 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user17 = experimentClass0.getInvalidUsers();
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user16);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user17);

  }

  @Test
  public void test150() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test150"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    de.tu.darmstadt.sola.ExperimentClass experimentClass11 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass11.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b17 = experimentClass11.isValidUser(user16);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user18 = experimentClass11.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("sampleInitParameter", "DECIMAL[(M[,D])]{n}", (int)(byte)100);
    boolean b23 = experimentClass11.isValidUser(user22);
    boolean b24 = experimentClass0.isValidUser(user22);
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User(".jar", "", 100);
    boolean b29 = experimentClass0.isValidUser(user28);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("graph");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user18);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == false);

  }

  @Test
  public void test151() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test151"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user11 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", "/test?type=request-mapping", 10);
    boolean b12 = experimentClass0.isValidUser(user11);
    de.tu.darmstadt.sola.ExperimentClass experimentClass13 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user17 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b18 = experimentClass13.isValidUser(user17);
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b23 = experimentClass13.isValidUser(user22);
    de.tu.darmstadt.sola.ExperimentClass experimentClass24 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user25 = experimentClass24.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user29 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b30 = experimentClass24.isValidUser(user29);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user31 = experimentClass24.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user35 = new de.tu.darmstadt.sola.ExperimentClass.User("sampleInitParameter", "DECIMAL[(M[,D])]{n}", (int)(byte)100);
    boolean b36 = experimentClass24.isValidUser(user35);
    boolean b37 = experimentClass13.isValidUser(user35);
    de.tu.darmstadt.sola.ExperimentClass.User user41 = new de.tu.darmstadt.sola.ExperimentClass.User(".jar", "", 100);
    boolean b42 = experimentClass13.isValidUser(user41);
    de.tu.darmstadt.sola.ExperimentClass.User user46 = new de.tu.darmstadt.sola.ExperimentClass.User("DECIMAL[(M[,D])]{n}", "gonzo@muppetshow.com", (int)(byte)-1);
    boolean b47 = experimentClass13.isValidUser(user46);
    boolean b48 = experimentClass0.isValidUser(user46);
    de.tu.darmstadt.sola.ExperimentClass.User user52 = new de.tu.darmstadt.sola.ExperimentClass.User("", ".jar", (int)(byte)100);
    boolean b53 = experimentClass0.isValidUser(user52);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user25);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user31);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b53 == false);

  }

  @Test
  public void test152() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test152"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user6 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user10 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b11 = experimentClass0.isValidUser(user10);
    de.tu.darmstadt.sola.ExperimentClass.User user15 = new de.tu.darmstadt.sola.ExperimentClass.User("/context/servlet/path?one=1&two=2;three=3#fragment", ".sh", (int)(short)10);
    boolean b16 = experimentClass0.isValidUser(user15);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user17 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user21 = new de.tu.darmstadt.sola.ExperimentClass.User("/context/servlet/path?one=1&two=2;three=3#fragment", ".jar", (int)(byte)-1);
    boolean b22 = experimentClass0.isValidUser(user21);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("MyClient/1.0");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user6);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user17);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b22 == true);

  }

  @Test
  public void test153() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test153"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User(".omex", "id", (int)(byte)1);

  }

  @Test
  public void test154() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test154"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    de.tu.darmstadt.sola.ExperimentClass.User user14 = new de.tu.darmstadt.sola.ExperimentClass.User(".txt", "INTEGER[(L)] [UNSIGNED]", (int)(short)0);
    boolean b15 = experimentClass0.isValidUser(user14);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b15 == true);

  }

  @Test
  public void test155() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test155"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass13 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user17 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b18 = experimentClass13.isValidUser(user17);
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b23 = experimentClass13.isValidUser(user22);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user24 = experimentClass13.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user25 = experimentClass13.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user29 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b30 = experimentClass13.isValidUser(user29);
    de.tu.darmstadt.sola.ExperimentClass experimentClass31 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user35 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b36 = experimentClass31.isValidUser(user35);
    boolean b37 = experimentClass13.isValidUser(user35);
    de.tu.darmstadt.sola.ExperimentClass.User user41 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b42 = experimentClass13.isValidUser(user41);
    boolean b43 = experimentClass0.isValidUser(user41);
    de.tu.darmstadt.sola.ExperimentClass.User user47 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "", (int)'#');
    boolean b48 = experimentClass0.isValidUser(user47);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user49 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("history");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user24);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user25);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user49);

  }

  @Test
  public void test156() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test156"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user8 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user9 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user10 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass11 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user15 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b16 = experimentClass11.isValidUser(user15);
    de.tu.darmstadt.sola.ExperimentClass.User user20 = new de.tu.darmstadt.sola.ExperimentClass.User("/context/servlet/path?one=1&two=2;three=3#fragment", ".nt", 100);
    boolean b21 = experimentClass11.isValidUser(user20);
    de.tu.darmstadt.sola.ExperimentClass experimentClass22 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user26 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b27 = experimentClass22.isValidUser(user26);
    de.tu.darmstadt.sola.ExperimentClass experimentClass28 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user29 = experimentClass28.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user33 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b34 = experimentClass28.isValidUser(user33);
    boolean b35 = experimentClass22.isValidUser(user33);
    boolean b36 = experimentClass11.isValidUser(user33);
    boolean b37 = experimentClass0.isValidUser(user33);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user38 = experimentClass0.getInvalidUsers();
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user8);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user9);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user10);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user29);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user38);

  }

  @Test
  public void test157() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test157"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass13 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user17 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b18 = experimentClass13.isValidUser(user17);
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b23 = experimentClass13.isValidUser(user22);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user24 = experimentClass13.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user25 = experimentClass13.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user29 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b30 = experimentClass13.isValidUser(user29);
    de.tu.darmstadt.sola.ExperimentClass experimentClass31 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user35 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b36 = experimentClass31.isValidUser(user35);
    boolean b37 = experimentClass13.isValidUser(user35);
    de.tu.darmstadt.sola.ExperimentClass.User user41 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b42 = experimentClass13.isValidUser(user41);
    boolean b43 = experimentClass0.isValidUser(user41);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("MyClient/1.0");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user24);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user25);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b43 == true);

  }

  @Test
  public void test158() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test158"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user11 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", "/test?type=request-mapping", 10);
    boolean b12 = experimentClass0.isValidUser(user11);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user13 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers(".sh");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user13);

  }

  @Test
  public void test159() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test159"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass13 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user17 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b18 = experimentClass13.isValidUser(user17);
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b23 = experimentClass13.isValidUser(user22);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user24 = experimentClass13.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user25 = experimentClass13.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user29 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b30 = experimentClass13.isValidUser(user29);
    de.tu.darmstadt.sola.ExperimentClass experimentClass31 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user35 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b36 = experimentClass31.isValidUser(user35);
    boolean b37 = experimentClass13.isValidUser(user35);
    de.tu.darmstadt.sola.ExperimentClass.User user41 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b42 = experimentClass13.isValidUser(user41);
    boolean b43 = experimentClass0.isValidUser(user41);
    de.tu.darmstadt.sola.ExperimentClass.User user47 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "", (int)'#');
    boolean b48 = experimentClass0.isValidUser(user47);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user49 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user50 = experimentClass0.getInvalidUsers();
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user24);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user25);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user49);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user50);

  }

  @Test
  public void test160() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test160"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user8 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass9 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user13 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b14 = experimentClass9.isValidUser(user13);
    de.tu.darmstadt.sola.ExperimentClass experimentClass15 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user19 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b20 = experimentClass15.isValidUser(user19);
    boolean b21 = experimentClass9.isValidUser(user19);
    boolean b22 = experimentClass0.isValidUser(user19);
    de.tu.darmstadt.sola.ExperimentClass experimentClass23 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass experimentClass24 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b29 = experimentClass24.isValidUser(user28);
    de.tu.darmstadt.sola.ExperimentClass experimentClass30 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user31 = experimentClass30.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user35 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b36 = experimentClass30.isValidUser(user35);
    boolean b37 = experimentClass24.isValidUser(user35);
    de.tu.darmstadt.sola.ExperimentClass.User user41 = new de.tu.darmstadt.sola.ExperimentClass.User("ksessionThatHasBeenRemovedFromKModuleXML", "/test", (int)' ');
    boolean b42 = experimentClass24.isValidUser(user41);
    boolean b43 = experimentClass23.isValidUser(user41);
    boolean b44 = experimentClass0.isValidUser(user41);
    de.tu.darmstadt.sola.ExperimentClass experimentClass45 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user49 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b50 = experimentClass45.isValidUser(user49);
    de.tu.darmstadt.sola.ExperimentClass experimentClass51 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user55 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b56 = experimentClass51.isValidUser(user55);
    de.tu.darmstadt.sola.ExperimentClass.User user60 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b61 = experimentClass51.isValidUser(user60);
    de.tu.darmstadt.sola.ExperimentClass experimentClass62 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user63 = experimentClass62.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user67 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b68 = experimentClass62.isValidUser(user67);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user69 = experimentClass62.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user73 = new de.tu.darmstadt.sola.ExperimentClass.User("sampleInitParameter", "DECIMAL[(M[,D])]{n}", (int)(byte)100);
    boolean b74 = experimentClass62.isValidUser(user73);
    boolean b75 = experimentClass51.isValidUser(user73);
    de.tu.darmstadt.sola.ExperimentClass.User user79 = new de.tu.darmstadt.sola.ExperimentClass.User(".jar", "", 100);
    boolean b80 = experimentClass51.isValidUser(user79);
    boolean b81 = experimentClass45.isValidUser(user79);
    de.tu.darmstadt.sola.ExperimentClass experimentClass82 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user83 = experimentClass82.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user87 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b88 = experimentClass82.isValidUser(user87);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user89 = experimentClass82.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user93 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b94 = experimentClass82.isValidUser(user93);
    boolean b95 = experimentClass45.isValidUser(user93);
    boolean b96 = experimentClass0.isValidUser(user93);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user8);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user31);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user63);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user69);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user83);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b88 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user89);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b94 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b95 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b96 == true);

  }

  @Test
  public void test161() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test161"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User(".bundle.zip", "id", (int)'4');

  }

  @Test
  public void test162() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test162"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass experimentClass6 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user10 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b11 = experimentClass6.isValidUser(user10);
    de.tu.darmstadt.sola.ExperimentClass.User user15 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b16 = experimentClass6.isValidUser(user15);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user17 = experimentClass6.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user18 = experimentClass6.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b23 = experimentClass6.isValidUser(user22);
    de.tu.darmstadt.sola.ExperimentClass experimentClass24 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b29 = experimentClass24.isValidUser(user28);
    boolean b30 = experimentClass6.isValidUser(user28);
    de.tu.darmstadt.sola.ExperimentClass.User user34 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b35 = experimentClass6.isValidUser(user34);
    boolean b36 = experimentClass0.isValidUser(user34);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user37 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("Gonzo");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user17);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user18);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user37);

  }

  @Test
  public void test163() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test163"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user8 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass9 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user13 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b14 = experimentClass9.isValidUser(user13);
    de.tu.darmstadt.sola.ExperimentClass experimentClass15 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user19 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b20 = experimentClass15.isValidUser(user19);
    boolean b21 = experimentClass9.isValidUser(user19);
    boolean b22 = experimentClass0.isValidUser(user19);
    de.tu.darmstadt.sola.ExperimentClass experimentClass23 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass experimentClass24 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b29 = experimentClass24.isValidUser(user28);
    de.tu.darmstadt.sola.ExperimentClass experimentClass30 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user31 = experimentClass30.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user35 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b36 = experimentClass30.isValidUser(user35);
    boolean b37 = experimentClass24.isValidUser(user35);
    de.tu.darmstadt.sola.ExperimentClass.User user41 = new de.tu.darmstadt.sola.ExperimentClass.User("ksessionThatHasBeenRemovedFromKModuleXML", "/test", (int)' ');
    boolean b42 = experimentClass24.isValidUser(user41);
    boolean b43 = experimentClass23.isValidUser(user41);
    boolean b44 = experimentClass0.isValidUser(user41);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user45 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("Gonzo");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user8);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user31);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user45);

  }

  @Test
  public void test164() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test164"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User(".bundle.zip", "fozzie", 1);

  }

  @Test
  public void test165() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test165"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("history", "Fozzie", (int)(short)-1);

  }

  @Test
  public void test166() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test166"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user6 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user10 = new de.tu.darmstadt.sola.ExperimentClass.User("DECIMAL[(M[,D])]{n}", "gonzo@muppetshow.com", (int)(byte)-1);
    boolean b11 = experimentClass0.isValidUser(user10);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("fozzie");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user6);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);

  }

  @Test
  public void test167() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test167"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user11 = new de.tu.darmstadt.sola.ExperimentClass.User("sampleInitParameter", "DECIMAL[(M[,D])]{n}", (int)(byte)100);
    boolean b12 = experimentClass0.isValidUser(user11);
    de.tu.darmstadt.sola.ExperimentClass experimentClass13 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user14 = experimentClass13.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user18 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b19 = experimentClass13.isValidUser(user18);
    boolean b20 = experimentClass0.isValidUser(user18);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user21 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user22 = experimentClass0.getInvalidUsers();
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user14);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user21);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user22);

  }

  @Test
  public void test168() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test168"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass experimentClass6 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user10 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b11 = experimentClass6.isValidUser(user10);
    de.tu.darmstadt.sola.ExperimentClass.User user15 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b16 = experimentClass6.isValidUser(user15);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user17 = experimentClass6.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user18 = experimentClass6.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b23 = experimentClass6.isValidUser(user22);
    de.tu.darmstadt.sola.ExperimentClass experimentClass24 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b29 = experimentClass24.isValidUser(user28);
    boolean b30 = experimentClass6.isValidUser(user28);
    de.tu.darmstadt.sola.ExperimentClass.User user34 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b35 = experimentClass6.isValidUser(user34);
    boolean b36 = experimentClass0.isValidUser(user34);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user37 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user38 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user39 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user40 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass41 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user45 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b46 = experimentClass41.isValidUser(user45);
    de.tu.darmstadt.sola.ExperimentClass.User user50 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b51 = experimentClass41.isValidUser(user50);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user52 = experimentClass41.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user53 = experimentClass41.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user57 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b58 = experimentClass41.isValidUser(user57);
    de.tu.darmstadt.sola.ExperimentClass experimentClass59 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user63 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b64 = experimentClass59.isValidUser(user63);
    boolean b65 = experimentClass41.isValidUser(user63);
    de.tu.darmstadt.sola.ExperimentClass.User user69 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b70 = experimentClass41.isValidUser(user69);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user71 = experimentClass41.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass72 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user76 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b77 = experimentClass72.isValidUser(user76);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user78 = experimentClass72.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user82 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b83 = experimentClass72.isValidUser(user82);
    boolean b84 = experimentClass41.isValidUser(user82);
    boolean b85 = experimentClass0.isValidUser(user82);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user86 = experimentClass0.getInvalidUsers();
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user17);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user18);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user37);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user38);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user39);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user40);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user52);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user53);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user71);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b77 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user78);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b83 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b85 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user86);

  }

  @Test
  public void test169() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test169"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user15 = new de.tu.darmstadt.sola.ExperimentClass.User("MyClient/1.0", "bundle", 10);
    boolean b16 = experimentClass0.isValidUser(user15);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user17 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user21 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "", (int)'#');
    boolean b22 = experimentClass0.isValidUser(user21);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user23 = experimentClass0.getInvalidUsers();
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user17);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user23);

  }

  @Test
  public void test170() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test170"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user6 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user10 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b11 = experimentClass0.isValidUser(user10);
    de.tu.darmstadt.sola.ExperimentClass.User user15 = new de.tu.darmstadt.sola.ExperimentClass.User("/context/servlet/path?one=1&two=2;three=3#fragment", "gonzo@muppetshow.com", (int)' ');
    boolean b16 = experimentClass0.isValidUser(user15);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("testbundle");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user6);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b16 == false);

  }

  @Test
  public void test171() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test171"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("Fozzie", "admin", (int)' ');

  }

  @Test
  public void test172() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test172"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("/context/servlet/path?one=1&two=2;three=3#fragment", ".nt", 100);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass12 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b17 = experimentClass12.isValidUser(user16);
    de.tu.darmstadt.sola.ExperimentClass.User user21 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b22 = experimentClass12.isValidUser(user21);
    de.tu.darmstadt.sola.ExperimentClass experimentClass23 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user24 = experimentClass23.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b29 = experimentClass23.isValidUser(user28);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user30 = experimentClass23.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user34 = new de.tu.darmstadt.sola.ExperimentClass.User("sampleInitParameter", "DECIMAL[(M[,D])]{n}", (int)(byte)100);
    boolean b35 = experimentClass23.isValidUser(user34);
    boolean b36 = experimentClass12.isValidUser(user34);
    de.tu.darmstadt.sola.ExperimentClass.User user40 = new de.tu.darmstadt.sola.ExperimentClass.User(".jar", "", 100);
    boolean b41 = experimentClass12.isValidUser(user40);
    de.tu.darmstadt.sola.ExperimentClass.User user45 = new de.tu.darmstadt.sola.ExperimentClass.User("DECIMAL[(M[,D])]{n}", "gonzo@muppetshow.com", (int)(byte)-1);
    boolean b46 = experimentClass12.isValidUser(user45);
    boolean b47 = experimentClass0.isValidUser(user45);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("fozzie@muppetshow.com");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user24);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user30);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b47 == true);

  }

  @Test
  public void test173() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test173"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("INTEGER[(L)] [UNSIGNED]", "/context/servlet/path?one=1&two=2;three=3#fragment", (int)'#');

  }

  @Test
  public void test174() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test174"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("staging", "shoesize", 100);

  }

  @Test
  public void test175() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test175"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user6 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user8 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("shoesize");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user6);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user8);

  }

  @Test
  public void test176() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test176"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass experimentClass6 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass6.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user11 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b12 = experimentClass6.isValidUser(user11);
    boolean b13 = experimentClass0.isValidUser(user11);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("gonzo");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b13 == true);

  }

  @Test
  public void test177() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test177"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user11 = new de.tu.darmstadt.sola.ExperimentClass.User("sampleInitParameter", "DECIMAL[(M[,D])]{n}", (int)(byte)100);
    boolean b12 = experimentClass0.isValidUser(user11);
    de.tu.darmstadt.sola.ExperimentClass experimentClass13 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user14 = experimentClass13.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user18 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b19 = experimentClass13.isValidUser(user18);
    boolean b20 = experimentClass0.isValidUser(user18);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user21 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("gonzo@muppetshow.com");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user14);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user21);

  }

  @Test
  public void test178() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test178"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("/context/servlet/path?one=1&two=2;three=3#fragment", ".nt", 100);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers(".sh");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);

  }

  @Test
  public void test179() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test179"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("/context/servlet/path?one=1&two=2;three=3#fragment", ".nt", 100);
    boolean b10 = experimentClass0.isValidUser(user9);
    de.tu.darmstadt.sola.ExperimentClass experimentClass11 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user15 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b16 = experimentClass11.isValidUser(user15);
    de.tu.darmstadt.sola.ExperimentClass.User user20 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b21 = experimentClass11.isValidUser(user20);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user22 = experimentClass11.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user23 = experimentClass11.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user27 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b28 = experimentClass11.isValidUser(user27);
    de.tu.darmstadt.sola.ExperimentClass experimentClass29 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user33 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b34 = experimentClass29.isValidUser(user33);
    boolean b35 = experimentClass11.isValidUser(user33);
    de.tu.darmstadt.sola.ExperimentClass.User user39 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b40 = experimentClass11.isValidUser(user39);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user41 = experimentClass11.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user45 = new de.tu.darmstadt.sola.ExperimentClass.User(".nt", "multipleEntities", (int)' ');
    boolean b46 = experimentClass11.isValidUser(user45);
    boolean b47 = experimentClass0.isValidUser(user45);
    de.tu.darmstadt.sola.ExperimentClass.User user51 = new de.tu.darmstadt.sola.ExperimentClass.User("/server/path?one=1&two=2;three=3&duplicate=A;duplicate=B#fragment", "", (int)(byte)100);
    boolean b52 = experimentClass0.isValidUser(user51);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("zip");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user22);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user23);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user41);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b52 == false);

  }

  @Test
  public void test180() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test180"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    de.tu.darmstadt.sola.ExperimentClass experimentClass11 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass11.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b17 = experimentClass11.isValidUser(user16);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user18 = experimentClass11.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("sampleInitParameter", "DECIMAL[(M[,D])]{n}", (int)(byte)100);
    boolean b23 = experimentClass11.isValidUser(user22);
    boolean b24 = experimentClass0.isValidUser(user22);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("[UNSIGNED] INTEGER");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user18);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b24 == false);

  }

  @Test
  public void test181() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test181"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("multipleEntities", "/test?type=request-mapping", (int)(short)1);

  }

  @Test
  public void test182() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test182"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    de.tu.darmstadt.sola.ExperimentClass.User user14 = new de.tu.darmstadt.sola.ExperimentClass.User("gonzo", "ksessionThatHasBeenRemovedFromKModuleXML", (int)'4');
    boolean b15 = experimentClass0.isValidUser(user14);
    de.tu.darmstadt.sola.ExperimentClass.User user19 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b20 = experimentClass0.isValidUser(user19);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user21 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user22 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass23 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user27 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b28 = experimentClass23.isValidUser(user27);
    de.tu.darmstadt.sola.ExperimentClass.User user32 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b33 = experimentClass23.isValidUser(user32);
    de.tu.darmstadt.sola.ExperimentClass.User user37 = new de.tu.darmstadt.sola.ExperimentClass.User("gonzo", "ksessionThatHasBeenRemovedFromKModuleXML", (int)'4');
    boolean b38 = experimentClass23.isValidUser(user37);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user39 = experimentClass23.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user43 = new de.tu.darmstadt.sola.ExperimentClass.User("history", "", (int)(short)-1);
    boolean b44 = experimentClass23.isValidUser(user43);
    de.tu.darmstadt.sola.ExperimentClass experimentClass45 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user49 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b50 = experimentClass45.isValidUser(user49);
    de.tu.darmstadt.sola.ExperimentClass experimentClass51 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user55 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b56 = experimentClass51.isValidUser(user55);
    de.tu.darmstadt.sola.ExperimentClass.User user60 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b61 = experimentClass51.isValidUser(user60);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user62 = experimentClass51.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user63 = experimentClass51.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user67 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b68 = experimentClass51.isValidUser(user67);
    de.tu.darmstadt.sola.ExperimentClass experimentClass69 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user73 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b74 = experimentClass69.isValidUser(user73);
    boolean b75 = experimentClass51.isValidUser(user73);
    de.tu.darmstadt.sola.ExperimentClass.User user79 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b80 = experimentClass51.isValidUser(user79);
    boolean b81 = experimentClass45.isValidUser(user79);
    boolean b82 = experimentClass23.isValidUser(user79);
    boolean b83 = experimentClass0.isValidUser(user79);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user21);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user22);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user39);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user62);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user63);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b80 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b81 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b82 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b83 == true);

  }

  @Test
  public void test183() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test183"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user6 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user10 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b11 = experimentClass0.isValidUser(user10);
    de.tu.darmstadt.sola.ExperimentClass.User user15 = new de.tu.darmstadt.sola.ExperimentClass.User("/context/servlet/path?one=1&two=2;three=3#fragment", ".sh", (int)(short)10);
    boolean b16 = experimentClass0.isValidUser(user15);
    de.tu.darmstadt.sola.ExperimentClass.User user20 = new de.tu.darmstadt.sola.ExperimentClass.User("bundle", "admin", (int)'#');
    boolean b21 = experimentClass0.isValidUser(user20);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user6);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b21 == false);

  }

  @Test
  public void test184() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test184"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass experimentClass6 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user10 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b11 = experimentClass6.isValidUser(user10);
    de.tu.darmstadt.sola.ExperimentClass.User user15 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b16 = experimentClass6.isValidUser(user15);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user17 = experimentClass6.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user18 = experimentClass6.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b23 = experimentClass6.isValidUser(user22);
    de.tu.darmstadt.sola.ExperimentClass experimentClass24 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b29 = experimentClass24.isValidUser(user28);
    boolean b30 = experimentClass6.isValidUser(user28);
    de.tu.darmstadt.sola.ExperimentClass.User user34 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b35 = experimentClass6.isValidUser(user34);
    boolean b36 = experimentClass0.isValidUser(user34);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user37 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user38 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user39 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user40 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers(".sh");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user17);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user18);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user37);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user38);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user39);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user40);

  }

  @Test
  public void test185() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test185"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user6 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user10 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b11 = experimentClass0.isValidUser(user10);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("staging");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user6);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b11 == false);

  }

  @Test
  public void test186() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test186"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass13 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user17 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b18 = experimentClass13.isValidUser(user17);
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b23 = experimentClass13.isValidUser(user22);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user24 = experimentClass13.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user25 = experimentClass13.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user29 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b30 = experimentClass13.isValidUser(user29);
    de.tu.darmstadt.sola.ExperimentClass experimentClass31 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user35 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b36 = experimentClass31.isValidUser(user35);
    boolean b37 = experimentClass13.isValidUser(user35);
    de.tu.darmstadt.sola.ExperimentClass.User user41 = new de.tu.darmstadt.sola.ExperimentClass.User(".tmp", ".test", 1);
    boolean b42 = experimentClass13.isValidUser(user41);
    boolean b43 = experimentClass0.isValidUser(user41);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("Gonzo");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user24);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user25);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b43 == true);

  }

  @Test
  public void test187() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test187"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("ksession2", "Boris", (int)(byte)-1);

  }

  @Test
  public void test188() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test188"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user8 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user12 = new de.tu.darmstadt.sola.ExperimentClass.User("", "/context/servlet/path?one=1&two=2;three=3#fragment", (int)(short)100);
    boolean b13 = experimentClass0.isValidUser(user12);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user14 = experimentClass0.getInvalidUsers();
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers(".xml");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user8);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user14);

  }

  @Test
  public void test189() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test189"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user8 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass9 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user13 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b14 = experimentClass9.isValidUser(user13);
    de.tu.darmstadt.sola.ExperimentClass experimentClass15 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user19 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b20 = experimentClass15.isValidUser(user19);
    boolean b21 = experimentClass9.isValidUser(user19);
    boolean b22 = experimentClass0.isValidUser(user19);
    // The following exception was thrown during execution in test generation
    try {
    experimentClass0.loadUsers("shoesize");
      org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException");
    } catch (java.io.FileNotFoundException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user8);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b22 == true);

  }

  @Test
  public void test190() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test190"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("DECIMAL[(M[,D])]{n}", "TEXT [CHARACTER SET]", (int)(byte)0);

  }

  @Test
  public void test191() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test191"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user6 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass8 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user12 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b13 = experimentClass8.isValidUser(user12);
    de.tu.darmstadt.sola.ExperimentClass.User user17 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b18 = experimentClass8.isValidUser(user17);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user19 = experimentClass8.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user20 = experimentClass8.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user24 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b25 = experimentClass8.isValidUser(user24);
    de.tu.darmstadt.sola.ExperimentClass experimentClass26 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user30 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b31 = experimentClass26.isValidUser(user30);
    boolean b32 = experimentClass8.isValidUser(user30);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user33 = experimentClass8.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass34 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user38 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b39 = experimentClass34.isValidUser(user38);
    de.tu.darmstadt.sola.ExperimentClass experimentClass40 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user41 = experimentClass40.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user45 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b46 = experimentClass40.isValidUser(user45);
    boolean b47 = experimentClass34.isValidUser(user45);
    de.tu.darmstadt.sola.ExperimentClass.User user51 = new de.tu.darmstadt.sola.ExperimentClass.User("ksessionThatHasBeenRemovedFromKModuleXML", "/test", (int)' ');
    boolean b52 = experimentClass34.isValidUser(user51);
    boolean b53 = experimentClass8.isValidUser(user51);
    boolean b54 = experimentClass0.isValidUser(user51);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user6);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user19);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user20);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user33);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user41);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b54 == false);

  }

  @Test
  public void test192() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test192"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass experimentClass6 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user10 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b11 = experimentClass6.isValidUser(user10);
    de.tu.darmstadt.sola.ExperimentClass.User user15 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b16 = experimentClass6.isValidUser(user15);
    de.tu.darmstadt.sola.ExperimentClass experimentClass17 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user18 = experimentClass17.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b23 = experimentClass17.isValidUser(user22);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user24 = experimentClass17.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User("sampleInitParameter", "DECIMAL[(M[,D])]{n}", (int)(byte)100);
    boolean b29 = experimentClass17.isValidUser(user28);
    boolean b30 = experimentClass6.isValidUser(user28);
    de.tu.darmstadt.sola.ExperimentClass.User user34 = new de.tu.darmstadt.sola.ExperimentClass.User(".jar", "", 100);
    boolean b35 = experimentClass6.isValidUser(user34);
    boolean b36 = experimentClass0.isValidUser(user34);
    de.tu.darmstadt.sola.ExperimentClass experimentClass37 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user38 = experimentClass37.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user42 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b43 = experimentClass37.isValidUser(user42);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user44 = experimentClass37.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user48 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b49 = experimentClass37.isValidUser(user48);
    boolean b50 = experimentClass0.isValidUser(user48);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user51 = experimentClass0.getInvalidUsers();
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user18);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user24);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user38);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user44);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user51);

  }

  @Test
  public void test193() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test193"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass experimentClass6 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass6.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user11 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b12 = experimentClass6.isValidUser(user11);
    boolean b13 = experimentClass0.isValidUser(user11);
    de.tu.darmstadt.sola.ExperimentClass.User user17 = new de.tu.darmstadt.sola.ExperimentClass.User("ksessionThatHasBeenRemovedFromKModuleXML", "/test", (int)' ');
    boolean b18 = experimentClass0.isValidUser(user17);
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("MyClient/1.0", "/context/servlet/path?name=value", (int)' ');
    boolean b23 = experimentClass0.isValidUser(user22);
    de.tu.darmstadt.sola.ExperimentClass experimentClass24 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user28 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b29 = experimentClass24.isValidUser(user28);
    de.tu.darmstadt.sola.ExperimentClass.User user33 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b34 = experimentClass24.isValidUser(user33);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user35 = experimentClass24.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user36 = experimentClass24.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user40 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b41 = experimentClass24.isValidUser(user40);
    boolean b42 = experimentClass0.isValidUser(user40);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user35);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user36);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b42 == true);

  }

  @Test
  public void test194() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test194"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("DECIMAL(3)", "zip", (int)(short)100);

  }

  @Test
  public void test195() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test195"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass experimentClass1 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b6 = experimentClass1.isValidUser(user5);
    de.tu.darmstadt.sola.ExperimentClass experimentClass7 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user8 = experimentClass7.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user12 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b13 = experimentClass7.isValidUser(user12);
    boolean b14 = experimentClass1.isValidUser(user12);
    de.tu.darmstadt.sola.ExperimentClass.User user18 = new de.tu.darmstadt.sola.ExperimentClass.User("ksessionThatHasBeenRemovedFromKModuleXML", "/test", (int)' ');
    boolean b19 = experimentClass1.isValidUser(user18);
    boolean b20 = experimentClass0.isValidUser(user18);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user21 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user22 = experimentClass0.getInvalidUsers();
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user8);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user21);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user22);

  }

  @Test
  public void test196() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test196"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("/context/servlet/path?one=1&two=2;three=3#fragment", ".nt", 100);
    boolean b10 = experimentClass0.isValidUser(user9);
    de.tu.darmstadt.sola.ExperimentClass.User user14 = new de.tu.darmstadt.sola.ExperimentClass.User(".nt", "gonzo@muppetshow.com", (int)'a');
    boolean b15 = experimentClass0.isValidUser(user14);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user16 = experimentClass0.getInvalidUsers();
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user16);

  }

  @Test
  public void test197() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test197"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("DECIMAL[(M[,D])]{n}", "DECIMAL(3)", 10);

  }

  @Test
  public void test198() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test198"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user1 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user5 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b6 = experimentClass0.isValidUser(user5);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user7 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user11 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b12 = experimentClass0.isValidUser(user11);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user13 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass14 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user18 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b19 = experimentClass14.isValidUser(user18);
    de.tu.darmstadt.sola.ExperimentClass.User user23 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b24 = experimentClass14.isValidUser(user23);
    de.tu.darmstadt.sola.ExperimentClass experimentClass25 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user26 = experimentClass25.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user30 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b31 = experimentClass25.isValidUser(user30);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user32 = experimentClass25.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user36 = new de.tu.darmstadt.sola.ExperimentClass.User("sampleInitParameter", "DECIMAL[(M[,D])]{n}", (int)(byte)100);
    boolean b37 = experimentClass25.isValidUser(user36);
    boolean b38 = experimentClass14.isValidUser(user36);
    de.tu.darmstadt.sola.ExperimentClass.User user42 = new de.tu.darmstadt.sola.ExperimentClass.User(".jar", "", 100);
    boolean b43 = experimentClass14.isValidUser(user42);
    de.tu.darmstadt.sola.ExperimentClass.User user47 = new de.tu.darmstadt.sola.ExperimentClass.User("DECIMAL[(M[,D])]{n}", "gonzo@muppetshow.com", (int)(byte)-1);
    boolean b48 = experimentClass14.isValidUser(user47);
    boolean b49 = experimentClass0.isValidUser(user47);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user1);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user7);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user13);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user26);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user32);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b49 == true);

  }

  @Test
  public void test199() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test199"); }

    de.tu.darmstadt.sola.ExperimentClass.User user3 = new de.tu.darmstadt.sola.ExperimentClass.User("default://object/store", "/test?type=REQUEST", 100);

  }

  @Test
  public void test200() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test200"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user6 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user10 = new de.tu.darmstadt.sola.ExperimentClass.User("", "Fozzie", (int)(short)-1);
    boolean b11 = experimentClass0.isValidUser(user10);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user6);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b11 == true);

  }

  @Test
  public void test201() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest0.test201"); }

    de.tu.darmstadt.sola.ExperimentClass experimentClass0 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user4 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b5 = experimentClass0.isValidUser(user4);
    de.tu.darmstadt.sola.ExperimentClass.User user9 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b10 = experimentClass0.isValidUser(user9);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user11 = experimentClass0.getInvalidUsers();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user12 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user16 = new de.tu.darmstadt.sola.ExperimentClass.User("fozzie", "hi!", 0);
    boolean b17 = experimentClass0.isValidUser(user16);
    de.tu.darmstadt.sola.ExperimentClass experimentClass18 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user22 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", (int)' ');
    boolean b23 = experimentClass18.isValidUser(user22);
    boolean b24 = experimentClass0.isValidUser(user22);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user25 = experimentClass0.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass experimentClass26 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user30 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b31 = experimentClass26.isValidUser(user30);
    de.tu.darmstadt.sola.ExperimentClass experimentClass32 = new de.tu.darmstadt.sola.ExperimentClass();
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user33 = experimentClass32.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user37 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b38 = experimentClass32.isValidUser(user37);
    boolean b39 = experimentClass26.isValidUser(user37);
    de.tu.darmstadt.sola.ExperimentClass.User user43 = new de.tu.darmstadt.sola.ExperimentClass.User("ksessionThatHasBeenRemovedFromKModuleXML", "/test", (int)' ');
    boolean b44 = experimentClass26.isValidUser(user43);
    boolean b45 = experimentClass0.isValidUser(user43);
    de.tu.darmstadt.sola.ExperimentClass experimentClass46 = new de.tu.darmstadt.sola.ExperimentClass();
    de.tu.darmstadt.sola.ExperimentClass.User user50 = new de.tu.darmstadt.sola.ExperimentClass.User("testbundle", "ksessionThatHasBeenRemovedFromKModuleXML", (int)(byte)10);
    boolean b51 = experimentClass46.isValidUser(user50);
    de.tu.darmstadt.sola.ExperimentClass.User user55 = new de.tu.darmstadt.sola.ExperimentClass.User("hi!", "MyClient/1.0", 0);
    boolean b56 = experimentClass46.isValidUser(user55);
    de.tu.darmstadt.sola.ExperimentClass.User user60 = new de.tu.darmstadt.sola.ExperimentClass.User("gonzo", "ksessionThatHasBeenRemovedFromKModuleXML", (int)'4');
    boolean b61 = experimentClass46.isValidUser(user60);
    java.util.List<de.tu.darmstadt.sola.ExperimentClass.User> list_user62 = experimentClass46.getInvalidUsers();
    de.tu.darmstadt.sola.ExperimentClass.User user66 = new de.tu.darmstadt.sola.ExperimentClass.User("history", "", (int)(short)-1);
    boolean b67 = experimentClass46.isValidUser(user66);
    boolean b68 = experimentClass0.isValidUser(user66);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user11);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user12);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user25);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user33);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertNotNull(list_user62);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b67 == true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(b68 == true);

  }

}
