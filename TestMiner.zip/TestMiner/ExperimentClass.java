package de.tu.darmstadt.sola;

import java.io.*;
import java.util.*;

public class ExperimentClass {
  private List<User> users = new ArrayList<>();

  public static class User {
    private final String name;
    private final String email;
    private final int age;

    public User(String name, String email, int age) {
      this.name = name;
      this.email = email;
      this.age = age;
    }
  }

  public void loadUsers(String filePath) throws IOException {
    try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
      String line;
      while ((line = br.readLine()) != null) {
        String[] data = line.split(",");
        users.add(new User(
            data[0].trim(),
            data[1].trim(),
            Integer.parseInt(data[2].trim())
        ));
      }
    }
  }
  
  public boolean isValidUser(User user) {
    return user.age < 18;
  }

  public List<User> getInvalidUsers() {
    List<User> invalid = new ArrayList<>();
    for (User user : users) {
      if (!isValidUser(user)) invalid.add(user);
    }
    return invalid;
  }
}