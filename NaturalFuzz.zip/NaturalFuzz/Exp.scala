package examples.tpcds

import org.apache.spark.{SparkConf, SparkContext}

object Exp extends Serializable {

  case class User(name: String, email: String, age: Int)

  def main(args: Array[String]) {
    //  def main(args: Array[String]): Unit = {
    println(s"Q1 called with args:\n${args.mkString("\n")}")
    val sparkConf = new SparkConf()
      .setMaster("local[*]")
      .setAppName("TPC-DS Query 1")
    val sc = SparkContext.getOrCreate(sparkConf)
    sc.setLogLevel("ERROR")
        // Константы для фильтрации
    val MIN_AGE = 18

    // Загрузка данных
    val Array(users) =  {
    val _users = sc.textFile(args(0)).map(_.split(","))
      Array(_users) }

    // Шаг 1: Подготовка данных пользователей
    val map1 = users.map(row => (row(1), row)) // Индексируем по email (второй столбец)

    println("map1 - первые 10 пользователей:")
    map1.take(10).foreach(println)

    // Шаг 2: Фильтрация валидных пользователей
    val safety1 = users.filter { row =>
      try {
        row(2).toInt // Проверяем что возраст - число
        true
      } catch {
        case _: Throwable => false
      }
    }
    
    val filter1 = safety1.filter(row => row(2).toInt < MIN_AGE)

    println(s"filter1 - пользователи старше $MIN_AGE лет:")
    filter1.take(10).foreach(println)
  }
}
