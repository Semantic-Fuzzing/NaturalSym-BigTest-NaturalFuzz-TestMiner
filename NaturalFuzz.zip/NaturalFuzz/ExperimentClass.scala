package examples.tpcds

import org.apache.spark.{SparkConf, SparkContext}

object ExperimentClass extends Serializable {

  case class User(name: String, email: String, age: Int)

  def main(args: Array[String]): Unit = {
    val sparkConf = new SparkConf()
    val ctx = SparkContext.getOrCreate(sparkConf)
    ctx.setLogLevel("ERROR")
        // Константы для фильтрации
    val MIN_AGE = 18

    // Загрузка данных
    val users = ctx.textFile(args(0)).map(_.split(","))

    // Шаг 1: Подготовка данных пользователей
    val map1 = users.map(row => (row(1), row)) // Индексируем по email (второй столбец)

    println("map1 - первые 10 пользователей:")
    map1.take(10).foreach(println)

    // Шаг 2: Фильтрация валидных пользователей
    val safety1 = users.filter { row =>
      try {
        row(2).toInt // Проверяем что возраст - число
        true
      } catch {
        case _: Throwable => false
      }
    }
    
    val filter1 = safety1.filter(row => row(2).toInt < MIN_AGE)

    println(s"filter1 - пользователи старше $MIN_AGE лет:")
    filter1.take(10).foreach(println)
  }
}
